actual class World {
    actual fun get(): String {
        return "Mac OS World"
    }
}
