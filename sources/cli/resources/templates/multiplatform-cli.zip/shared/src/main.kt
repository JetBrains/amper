import World

fun main() {
    println(" Multiplatform CLI: ${World().get()}")
}
