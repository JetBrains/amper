expect class World() {
    fun get() : String
}
