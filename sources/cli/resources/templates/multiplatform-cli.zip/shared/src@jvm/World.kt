actual class World {
    actual fun get(): String {
        return "JVM World"
    }
}
