actual class World {
    actual fun get(): String {
        return "Linux World"
    }
}
